<?php require_once("../resources/config.php"); ?>
<div id="rs-slider" class="slider-overlay-1"> 

            <div id="home-slider">
            <?php get_slider_images(); ?>
            </div>         
</div>