<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav">
        <li class="active">
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li class="">
            <a href="view/orders"><i class="fa fa-fw fa-history"></i> Orders</a>
        </li>
        <li>
            <a href="view/view_products"><i class="fa fa-fw fa-bar-chart-o"></i> View Products</a>
        </li>
        <li>
            <a href="view/add_products"><i class="fa fa-fw fa-table"></i> Add Product</a>
        </li>
        
        <li>
            <a href="view/categories"><i class="fa fa-fw fa-desktop"></i> Categories</a>
        </li>
        <li>
            <a href="view/users"><i class="fa fa-fw fa-child"></i>Users</a>
        </li>
         <li>
            <a href="view/reports"><i class="fa fa-fw fa-book"></i>Reports</a>
        </li>
    
    </ul>
</div>