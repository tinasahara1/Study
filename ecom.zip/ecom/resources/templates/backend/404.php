<?php 
echo "Fuck Man";
?>