


                


        <div class="col-md-12">
<div class="row">
<h1 class="page-header">
   All Reports

</h1>
<h2 class="text-center bg-danger"><?php display_msg(); ?></h2>
</div>

<div class="row">
<table class="table table-hover">
    <thead>

      <tr>
           <th>Report Id</th>
           <th>Order Id</th>
           <th>Product Id</th>
           <th>Product Title</th>
           <th>Product Price</th>
           <th>Product Quantity</th>
      </tr>
    </thead>
    <tbody>
        
        <?php get_reports(); ?>

    </tbody>
</table>
</div>











            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    